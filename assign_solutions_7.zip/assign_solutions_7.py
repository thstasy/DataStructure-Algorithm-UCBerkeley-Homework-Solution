#!/usr/bin/env python
# coding: utf-8

# 1. Write a function to solve the problem of finding the longest increasing subsequence in a given array of integers. Test your function on a few examples.

# In[ ]:


def longest_increasing_subsequence(array):
    n = len(array)
    if n == 0:
        return 0

    max_array = [1] * n

    for i in range(1, n):
        for j in range(i):
            if array[i] > array[j]:
                max_array[i] = max(max_array[i], max_array[j] + 1)

    return max(max_array)

# longest: 10, 22, 33, 50, 60, 80 
print(longest_increasing_subsequence([10, 22, 9, 33, 21, 50, 41, 60, 80])) 
# longest: 3, 10, 20
print(longest_increasing_subsequence([3, 10, 2, 1, 20]))                 

print(longest_increasing_subsequence([3, 2, 1]))                         

print(longest_increasing_subsequence([2, 3]))                         

print(longest_increasing_subsequence([]))                         


# 2. Consider the problem of cutting a rod of length n into smaller pieces in order to maximize the total value obtained from selling the pieces. Write a function to solve this problem and find the optimal solution for a rod of length 10.

# In[ ]:


def rod_cutting(n, prices):
    if n == 0:
        return 0

    max_array = [0] * (n + 1)

    for i in range(1, n + 1):
        max_value = 0
        for rod_length in range(1, i + 1):
            max_value = max(max_value, prices[rod_length] + max_array[i - rod_length])
        max_array[i] = max_value
    print(max_array)
    return max_array[n]


prices = [0, 2, 5, 8, 9, 10, 17, 17, 20, 24, 26]
print(rod_cutting(10, prices)) 

prices = [0, 3, 5, 8, 9, 10, 17, 17, 20, 24, 26]
# $3 x 10 x length 1
print(rod_cutting(10, prices)) 

prices = [0, 3, 5, 8, 9, 10, 17, 17, 25, 23, 29]
# $3 x 2 x length 1 + $25 x 1 x length 8
print(rod_cutting(10, prices)) 


# 3. Write a function to find the minimum number of coins required to make change for a given amount using a given set of coin denominations. 

# In[ ]:


def min_coin_change(amount, denominations):
    if amount == 0:
        return 0

    min_array = [float('inf')] * (amount + 1)
    min_array[0] = 0

    for coin in denominations:
        for i in range(coin, amount + 1):
            min_array[i] = min(min_array[i], min_array[i - coin] + 1)

    return min_array[amount] if min_array[amount] != float('inf') else -1

denominations = [1, 5, 10, 25]  # Denominations of coins: 1 cent, 5 cents, 10 cents, 25 cents
amount = 63  # Amount for which we want to make change

print(min_coin_change(amount, denominations))  # Output: 6 (2x 25 cents, 1x 5 cents, 3x 1 cent)
print(min_coin_change(22, denominations))  # Output: 4 (2x 10 cents, 2x 1 cent)


# 4. Dynamic programming works by breaking down problems into smaller subproblems and storing them in a cache. However, there are some types of problems where dynamic programming will not work or not be as effective. Describe an example where applying dynamic programming fails.

# (From ChatGPT)
# Dynamic programming is a powerful technique for solving many problems efficiently by breaking them down into smaller subproblems and storing intermediate results in a cache. However, there are certain types of problems for which dynamic programming may not be as effective or fail to provide significant advantages. One such example is the "Travelling Salesman Problem" (TSP).
# 
# The Travelling Salesman Problem is a classic optimization problem where a salesman is required to visit a set of cities, starting and ending at his home city, while minimizing the total distance traveled. The challenge is to find the shortest possible route that visits each city exactly once and returns to the starting city.
# 
# The issue with applying dynamic programming to the TSP is that the number of subproblems grows exponentially with the number of cities. In a brute-force approach, the number of potential routes to consider is (n-1)! for n cities. Therefore, storing all the subproblem solutions in a cache becomes impractical as the number of cities increases, and the time and space complexity becomes prohibitive.
# 
# Dynamic programming typically works best when the problem has overlapping subproblems, and the solutions to these subproblems can be reused efficiently. However, in the TSP, each subproblem is distinct, and there is no simple way to combine or reuse the solutions to smaller subproblems to solve the overall problem.
# 
# To tackle the Travelling Salesman Problem, specialized algorithms and heuristics like the "Branch and Bound" method or the "Ant Colony Optimization" are often employed to find approximate solutions efficiently, though they may not guarantee the optimal solution for all instances. The TSP remains a well-known example of a problem where dynamic programming is not a straightforward or efficient approach.

# In[ ]:




