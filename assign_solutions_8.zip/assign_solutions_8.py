#!/usr/bin/env python
# coding: utf-8

# 1. Native Python numbers do not have numerical overflow. This is possible by using a type called bignum, where numbers are limited only by a computer's memory. How would you implement bignum?

# Bignum, short for "big number," allows numbers to grow to any size that can be accommodated by the computer's memory.
# 
# In traditional fixed-size integer representations, there is an upper limit for the maximum value that can be stored. If the result of an arithmetic operation exceeds this limit, an overflow may occur, leading to incorrect or unpredictable results. Bignum addresses this limitation by dynamically allocating memory to store the digits of the number, allowing it to scale without bounds. This can be done by storing digits of the number as a list of integers.
# 
# Algorithms for basic arithmetic operations like addition, subtraction, multiplication, and division, as well as functions for comparisons, conversions, and other mathematical operations must also be implemented.

# 2. Why is there no logical left shift operator in some programming languages? 

# 1. Historical Evolution: Many programming languages were designed before the concept of logical and arithmetic shifts was well-established. When these languages were initially developed, bitwise operations, including shifting, were commonly used for low-level operations on hardware and binary data manipulation. As a result, most languages provided a single left shift operator (usually denoted as `<<`), which performs an arithmetic shift in some languages and a logical shift in others.
# 
# 2. Language Simplicity: Some programming languages prioritize simplicity and consistency in their syntax and operators. Introducing a separate logical left shift operator can add complexity to the language and may not be considered necessary for the majority of use cases.
# 
# 3. Alternative Approaches: Some languages offer alternative ways to achieve a logical left shift behavior. For example, in languages like Python, the arithmetic left shift operator (`<<`) behaves as a logical left shift when dealing with unsigned integers, thanks to the language's dynamic typing and automatic handling of variable size.
# 
# Despite the absence of a dedicated logical left shift operator in some languages, bitwise manipulation can still be achieved through other means, such as using masks, bitwise AND (`&`), or using libraries or modules specifically designed for bit-level operations.
# 

# 3. Compare and contrast fixed point representation and floating point representation. Explain the advantages and disadvantages of each.

# Advantages of Fixed-Point Representation:
# * Deterministic behavior: Fixed-point arithmetic provides predictable results for arithmetic operations, making it suitable for applications where precision is essential.
# * Reduced memory and processing overhead: Fixed-point representation uses a fixed number of bits, which can result in lower memory and processing requirements compared to floating-point representation.
# 
# Disadvantages of Fixed-Point Representation:
# * Limited range and precision: The number of bits allocated for the integer and fractional parts limits the range and precision of numbers that can be represented, leading to potential loss of accuracy in certain calculations.
# * Difficulty handling very large or very small values: Fixed-point representation struggles to handle numbers with a wide range, as the position of the decimal point remains fixed.
# 
# Advantages of Floating-Point Representation:
#    * Wider range and precision: Floating-point representation can represent a broader range of values, both large and small, with varying levels of precision.
#    * Relative accuracy: Floating-point representation provides a relative accuracy across a wide range of magnitudes, making it suitable for many scientific computations.
# 
# Disadvantages of Floating-Point Representation:
#    * Non-deterministic behavior: Floating-point arithmetic can lead to rounding errors and inaccuracies due to the finite precision of the representation. This can cause issues in certain computations.
#    * Performance overhead: Floating-point operations are generally more complex and computationally intensive than fixed-point operations, which can impact performance, especially in resource-constrained systems.
# 
# 

# 4. What is the difference between UTF-8, UTF-16, and UTF-32 encoding formats?

# 1. UTF-8:
# * Variable-Length Encoding: UTF-8 uses a variable-length encoding scheme, where each Unicode character is represented by one to four bytes, depending on the character's code point.
#   * Space Efficiency: ASCII characters (code points 0 to 127) are represented with one byte in UTF-8, making it space-efficient for text that primarily consists of ASCII characters.
#    * Non-ASCII characters: Non-ASCII characters require two to four bytes in UTF-8, which may lead to slightly larger file sizes compared to UTF-16 or UTF-32 for certain languages with frequent use of non-ASCII characters.
#    * Commonly Used: UTF-8 is widely used in web-based applications, databases, and communication protocols, as it strikes a good balance between space efficiency and broad language support.
# 
# 2. UTF-16:
#    * Fixed-Length Encoding: UTF-16 uses a fixed-length encoding scheme, where each Unicode character is represented by two bytes (16 bits) or four bytes (surrogate pairs) if the code point is outside the Basic Multilingual Plane (BMP).
#    * Supplementary Characters: Characters beyond the BMP (code points U+10000 to U+10FFFF) are represented using surrogate pairs, which consist of two 16-bit code units.
#    * Space Efficiency: UTF-16 may require more space than UTF-8 for text that primarily consists of ASCII characters since each ASCII character is represented using two bytes in UTF-16.
#    * Commonly Used: UTF-16 is commonly used in Windows-based systems and some programming languages, like Java and JavaScript, where characters are represented as 16-bit values.
# 
# 3. UTF-32:
#    * Fixed-Length Encoding: UTF-32 uses a fixed-length encoding scheme, where each Unicode character is represented by four bytes (32 bits).
#    * Simplicity: UTF-32 offers a straightforward mapping between code points and the corresponding four-byte representation, making it easy to process and index individual characters in a string.
#    * Space Inefficiency: UTF-32 typically requires more space than UTF-8 or UTF-16, especially for text that primarily consists of ASCII characters.
#    * Commonly Used: UTF-32 is less commonly used in practice due to its space inefficiency compared to UTF-8 and UTF-16. However, it is used in certain specialized applications that require constant-time access to characters, such as certain string-processing algorithms.
# 
# In summary, the choice between UTF-8, UTF-16, and UTF-32 encoding formats depends on factors like space efficiency, language support, and platform compatibility. UTF-8 is the most widely used format due to its space efficiency and broad language support, especially for web-based applications and text storage. UTF-16 is commonly used in certain programming languages and Windows-based systems, while UTF-32 is less common and mostly used in specialized scenarios requiring constant-time character access.

# 5. Huffman Encoding is a variable length encoding, which means encoded characters do not necessarily have the same length in bits. Files are saved as fixed length bytes. How would you handle the case when the encoded data does not exactly fit in byte storage?

# When using Huffman Encoding, the encoded characters do not necessarily have the same length in bits, which can result in the encoded data not fitting exactly into byte storage. In such cases, some form of padding or additional handling is required to ensure that the encoded data can be correctly stored and retrieved.
# 
# There are several common approaches to handle this situation:
# 
# 1. Padding: One common approach is to pad the encoded data with extra bits to fill up the remaining space in the last byte. The number of padding bits needed can be calculated based on the number of bits required to store the last encoded character. While this ensures that the encoded data fits into byte storage, it may result in some wasted space if the padding bits are not fully utilized.
# 
# 2. Bitstream: Instead of storing the encoded data as fixed-length bytes, the encoded data can be stored as a bitstream. A bitstream is a sequence of bits that can vary in length and is not restricted to byte boundaries. Bitstreams allow for more efficient storage of variable-length encoded data, as it eliminates the need for padding and minimizes wasted space.
# 
# 3. Add a Length Header: Another approach is to add a header to the encoded data that indicates the length of the encoded data. The header can specify the number of bits used for each encoded character, allowing for accurate reconstruction of the original data during decoding.
# 
# 

# 6. Huffman Encoding has a good compression rate with textual data. However, the compression rate is lower for non-textual data. Explain why this is so and give examples of these types of non-textual data. 

# Huffman Encoding is a variable-length compression technique that works well for textual data, where certain characters appear more frequently than others. However, its compression rate is lower for non-textual data because it relies on the frequency of characters to create shorter codes for more common characters. Non-textual data typically lacks such repetitive patterns, leading to less effective compression. Here are some examples of non-textual data and why their compression rate is lower:
# 
# 1. Images:
#    Images consist of pixel data, where each pixel is represented by color values (e.g., RGB values for colored images). In most images, each color value is unique, and there are no repeating patterns across the entire image. 
# 
# 2. Audio:
#    Audio files contain samples of sound at various intervals. Similar to images, audio data usually lacks repetitive patterns over extended periods. 
# 
# 3. Video:
#    Video files consist of a sequence of images (frames) presented at a high speed. Each frame is essentially an image, and as discussed earlier, images have low compression potential with Huffman Encoding. Furthermore, video files have additional challenges like motion data and inter-frame dependencies, making Huffman Encoding less suitable for efficient compression.
# 
# 4. Executable Files:
#    Executable files contain machine code, and each instruction and data in the file is typically unique.
#    
# 6. Encrypted Data:
#    Encrypted data is designed to be indistinguishable from random data, and as a result, it does not exhibit any regular patterns or repetitive structures.
# 
# In summary, Huffman Encoding relies on the frequency of characters or symbols to create variable-length codes, making it more effective for compressing textual data with repetitive patterns. For non-textual data, such as images, audio, video, executable files, and encrypted data, the lack of repetitive patterns and the presence of more diverse and unique symbols limit the compression rate achievable with Huffman Encoding. For these types of data, other compression techniques, like lossless compression algorithms such as DEFLATE (used in ZIP files) or lossy compression techniques (used in JPEG and MP3), are often more suitable for achieving higher compression rates.

# In[ ]:




