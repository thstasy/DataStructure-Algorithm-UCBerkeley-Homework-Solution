#!/usr/bin/env python
# coding: utf-8

# 1. (15 points) Give at least two examples (in real life and in programming) and a short description for:
# 
# ##### Stacks - a data structure where items follow a LIFO principle (last in, first out)
# * function call stack
# * undo stacks
# * stacks of dishes
# * stacks of paper
# 
# ##### Queues - a data structure where items follow a FIFO principle (first in, first out)
# * printer queues
# * webserver request handling
# * movie queues
# * a toll booth
# 
# ##### Deques - a data structure that is a double ended queue - 
# * browser history 
# * undo tracking
# * task scheduling
# 

# 2. (25) Write a function that returns a Boolean as to whether a string has balanced braces. You may ignore non-bracket characters. For our purposes, the following are bracket characters: (){}[]

# For example, the following will return True: 

# In[ ]:


balanced = [ 
    "[]",
    "{}{}[]()",
    "[{()}]",
    "(()[[[()({})]]])"
]


# The following will return False:

# In[ ]:


unbalanced = [ 
    "[][",
    "{{}[](})",
    "[{)}]",
    "(()[()({})]]])"
]
 


# Simplified Solution

# In[ ]:


from dsa.stack import Stack

# inspired by student solutions 
def is_balanced(string):
    stk = Stack()
    brackets = { '{': '}',
                 '[': ']',
                 '(': ')' }

    for c in string:
        if c not in brackets.keys() and c not in brackets.values():
            continue # ignore non-bracket characters
        elif c in brackets: # if left bracket, just push it
            stk.push(c)
        else:
            # if the stack is empty, then pending right bracket makes it unbalanced
            # or if right bracket != bracket at top of the stack, then it is unbalanced
            if stk.is_empty() or c != brackets[stk.pop()]: 
                return False

    # if there are still items in the stack, then it is unabalanced
    return stk.is_empty()
    
balanced = [ 
    "[ ]",
    "{}{}[]( )",
    "[{()}]",
    "(()[[[( )({})]]])"
]

print("Balanced")
for brace in balanced:
    print(brace, is_balanced(brace))

unbalanced = [
    "]",
    "[][",
    "{{}[](} )",
    "[{)}]",
    "(()[()({})]]])"
]
print()
print("Unbalanced")
for brace in unbalanced:
    print(brace, is_balanced(brace))


# Original, Harder to understand solution

# In[ ]:


from dsa.stack import Stack

def is_balanced(string):
    stk = Stack()
    for c in string:
        if c not in "{}[]()":
            # skip non-bracket characters
            continue
        elif c in "([{":
            # push the left side of the bracket
            stk.push(c)
        else:
            if not stk.is_empty():
                # pop the left side if the current character is the corresponding right side
                top = stk.peek()
                if (top == "(" and c == ")") or (top == "{" and c == "}") or (top == "[" and c == "]"):
                    stk.pop()
                else:
                    # if not mached, then it is unbalanced
                    return False
            else:
                # if the stack is empty and we have a right sided bracket, then our string is unbalanced
                return False
    # if stack is empty, then we have processed all of our characters, then the string is balanced
    return stk.is_empty()

balanced = [ 
    "[]",
    "{}{}[]()",
    "[{()}]",
    "(()[[[()({})]]])"
]

print("Balanced")
for brace in balanced:
    print(brace, is_balanced(brace))

unbalanced = [
    "]",
    "[][",
    "{{}[](})",
    "[{)}]",
    "(()[()({})]]])"
]
print()
print("Unbalanced")
for brace in unbalanced:
    print(brace, is_balanced(brace))


# 3. (35 points) Fully implement the Deque data structure using an array.

# It should have the following methods:
# 
# * append_left(element)
# * append_right(element)
# * pop_left()
# * pop_right()
# * peek_left()
# * peek_right()
# * get_count()
# 
# It may also be helpful to implement a print method to display the contents of the deque in the correct order.
# 
# Make sure to test your code, especially for tricky situations.
# 
#  

# In[ ]:


class Deque:
    def __init__(self, capacity=10):
        self.array = [None] * capacity
        self.front = -1
        self.rear = 0
        self.count = 0
        
    def append_left(self, element):
        if self.count >= len(self.array):
            raise Exception("Deque Full")
        if self.front < 0:
            self.front = len(self.array) - 1
        self.array[self.front] = element
        self.front -= 1
        self.count += 1
        
    def append_right(self, element):
        ''' similar to stack push and queue enqueue '''
        if self.count >= len(self.array):
            raise Exception("Deque Full")
        if self.rear > len(self.array) - 1:
            self.rear = 0
        self.array[self.rear] = element
        self.rear += 1
        self.count += 1

    def pop_left(self):
        ''' similar to queue dequeue '''
        element = self.array[self.front + 1]
        self.front += 1
        if self.front + 1 >= len(self.array):
            self.front = -1
        self.count -= 1
        return element
    
    def pop_right(self):
        ''' similar to stack pop '''
        element = self.array[self.rear - 1]
        self.count -= 1

        self.rear -= 1
        if self.rear < 0:
            self.rear = len(self.array) - 1
        return element

    def peek_left(self):
        if len(self) == 0:
            raise Exception("Empty deque")
        return self.array[self.front + 1]

    def peek_right(self):
        if len(self) == 0:
            raise Exception("Empty deque")
        return self.array[self.rear - 1]
    
    def __len__(self):
        return self.count

    def get_count(self):
        return self.count
    
    def __repr__(self):
        arr = []
        for i in range(self.count):
            index = (i + self.front + 1) % len(self.array) 
            arr.append(str(self.array[index]))
        arrstr = ", ".join(arr)
        return f"[{arrstr}] Front: {self.front} Count: {self.count} Capacity: {len(self.array)}" # {self.array}"


# In[ ]:


dq = Deque()
dq.append_left('c')
dq.append_right('d')
dq.append_left('b')
dq.append_left('a')
dq.append_left('0')
dq


# In[ ]:


dq.append_right('e')
dq.append_right('f')
dq.append_right('g')
dq


# In[ ]:


dq.pop_left()


# In[ ]:


dq.pop_right()


# In[ ]:


dq


# In[ ]:


dq.append_left(3)
dq.append_left(2)
dq.append_left(1)
dq.append_left(0)
dq


# In[ ]:


dq.append_left(-1)


# In[ ]:


while not dq.is_empty():
    print(dq.pop_left())


# 4. (25 points) Write a recursive binary search function to search for an element in an array. Assume the elements in the array are sorted. It should return the index of the element and return -1 if it is not found.

# In[ ]:


def bin_search_index(array, target, left=0, right=-1):
    # set the right index to the length of the string 
    if right == -1:
        right = len(array)
        
    if left >= right:
        return -1
    
    mid = (left + right) // 2
    if array[mid] == target:
        return mid
    elif array[mid] < target:
        return bin_search_index(array, target, mid + 1, right)
    elif array[mid] > target:
        return bin_search_index(array, target, left, mid)
        

array = [-3, 2, 8, 9, 13, 15, 20, 53, 55, 55, 67, 91, 101]

print(bin_search_index(array, 0)) # returns -1
print(bin_search_index(array, 1)) # returns -1
print(bin_search_index(array, 2)) # returns 1
print(bin_search_index(array, 20)) # returns 6

print(bin_search_index([], 20)) # returns -1
print(bin_search_index([10, 20], 20)) # returns 1
print(bin_search_index([10, 20], 100)) # returns -1
print(bin_search_index([0, 10, 20], 0)) # returns 0
print(bin_search_index([0, 10, 20], 20)) # returns 2



