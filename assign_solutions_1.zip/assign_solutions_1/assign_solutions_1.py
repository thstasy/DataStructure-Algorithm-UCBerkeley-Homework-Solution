#!/usr/bin/env python
# coding: utf-8

# 1. (10 points) Write an example for each of the following. 
# Avoid using examples that were already discussed in class. Examples do not necessarily have to be programming related:
# 
# * O(1) constant time
#   - calculation of a formula such as converting inches to meters
# * O(log n) logarithmic time
#   - searching for a name in a phonebook (with binary search) n is the number of elements in the phonebook
# * O(n) linear time
#   - comparing two strings where n is the length of the string
#  (anything with iteration
#     - searching for a value in an array that is not sorted)
# * O(n log n) linearithmic time
#   - sorting algorithms such as quicksort, mergesort
# * O(n^2) exponential
#   - anything with nested loops such as two dimensional matrix multiplication
#  

# 2. (30 points) Write code to populate an array with size n with numbers from 0 to n-1. Next, shuffle (randomly reorder or rearrange)  the numbers in the array.
# 
# Do not use the shuffle() method/function. However, you can use the built-in random generator function.
# 
# And finally, provide the Big O notation for both the average and worst case time complexities of your code.

# Uses the algorithm in the following
# https://en.wikipedia.org/wiki/Fisher–Yates_shuffle
# 

# In[ ]:


import random

def fill_array(n):
    array = [None] * n
    for i in range(n):
        array[i] = i
    
    return array


def shuffle(array):
    ''' shuffles in-place '''
    length = len(array)
    for i in range(length):
        j = random.randint(i, length - 1)

        array[i], array[j] = array[j], array[i]
        # the above swap is equivalent to:
        # tmp = array[i]
        # array[i] = array[j]
        # array[j] = tmp
    return array

array = fill_array(1000)
shuffle(array)


# complexity: filling requires O(n) time and O(n) space. Suffling requires O(n) time. Performance is the same regardless of the values, so the worst case and the best case are the same.

# 3. Write a function that accepts a sorted array of integers and a target value. The array may contain duplicate values. It should return the count of the number of occurrences of the target value.
# 
# Full credit for a O(log n) solution and partial credit otherwise.

# In[ ]:


from dsa.array import Array

def find_index(array, start, end, target, find_first):
    index = -1
    while start <= end:
        mid = (start + end) // 2

        if target == array[mid]:
            # temporary storage for the most recent found value
            index = mid

            # there may be more to the left
            if find_first:
                end = mid - 1
            else:
                # there may be more to the right
                start = mid + 1
        elif target < array[mid]:
            end = mid - 1
        else:
            start = mid + 1
    return index  

def count_values(array, target):
    first_index = find_index(array, 0, array.count - 1, target, True)
    last_index = find_index(array, 0, array.count - 1, target, False)

    if first_index == -1 and last_index == -1:
        return 0
    else:
        return last_index - first_index + 1
    
array = Array([3, 4, 5, 6])
print(count_values(array, 3))
print(count_values(array, 0))

array = Array([1, 1, 1, 1, 2, 3, 4, 5, 6, 7])
print(count_values(array, 1))

array = Array([1, 5, 6, 7,7,7,7, 7,7,7])
print(count_values(array, 7))

array = Array([1, 6, 7,7,7, 7,7, 8, 8])
print(count_values(array, 7))



# 4. (30 points) Write a function to return the index of the largest value in a sorted, rotated array. Assume that the array is sorted in ascending order. A rotated array is an array that has had its elements shifted or rotated circularly to the left or right by a certain number of positions. This rotation does not change the elements themselves but changes their positions within the array.
# Examples:
# [1, 2, 3, 4, 5] -> [4, 5, 1, 2, 3]
# [0, 1, 3, 5, 7, 11] -> [5, 7, 11, 0, 1, 3]
# 
# Full credit for a O(log n) solution and partial credit otherwise.

# In a sorted array (ascending), the maximum number will always be the last index
# 
# When we have the same array, but is rotated, we need to look for the index
# where the order is incorrect. 
# 
# Using binary search, either our start index or end index will eventually refer to the maximum number

# In[ ]:


def find_max_index(array):
    start = 0
    end = len(array) - 1

    # return -1 for an empty array
    if end == -1:
        return -1
        
    while start <= end:
        mid = (start + end) // 2

        if start == mid:
            if array[start] > array[end]:
                return start
            else:
                return end

        # discrepancy is on the left half
        if array[mid] < array[start]:
            end = mid - 1
        # discrepancy is on the right half
        elif array[mid] > array[end]:
            start = mid
        else:
            return end
    return start


arrays = [
    [1],
    [1, 2],
    [2, 1],
    [1, 2, 3],
    [3, 1, 2],
    [2, 3, 1],
    [1, 2, 3, 4],
    [2, 3, 4, 1],
    [3, 4, 1, 2],
    [4, 1, 2, 3],
    [1, 2, 3, 4, 5],
    [3, 4, 5, 1, 2],
    [4, 5, 1, 2, 3],
    [5, 1, 2, 3, 4],
    [3, 5, 7, 11, 0, 1],
    [30, 51, 67, 78, 115],
    [115, 30, 51, 67, 78],
    [78, 115, 30, 51, 67, 78]
]

for array in arrays:
    index = find_max_index(array)
    print(f'Index: {index}  Max Value: {array[index]} ', array, max(array))
    


# In[ ]:


# cleaner solution, but uses negative indexes
def find_max_index(array):
    start = 0 
    end = len(array) - 1

    while start < end:
        mid = (start + end) // 2

        if array[mid] > array[end]:
            start = mid + 1
        else:
            end = mid
    
    return end - 1

for array in arrays:
    index = find_max_index(array)
    print(f'Index: {index}  Max Value: {array[index]} ', array, max(array))


# In[ ]:




