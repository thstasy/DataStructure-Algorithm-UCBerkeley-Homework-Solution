This is a cluster of *exercises of coding styles* from UC Berkeley's Data Structure and Algorithm. Thus, sometimes Python, sometimes Java.
