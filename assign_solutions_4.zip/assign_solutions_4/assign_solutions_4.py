#!/usr/bin/env python
# coding: utf-8

# 1. Write a function to reverse the elements in a doubly linked list. Do not simply print it out. It must have the references correctly set in reversed order.
# Also, write a print method – this should help with debugging.
# 
# 

# In[ ]:


class Node:
    def __init__(self, value):
        self.value = value
        self.next = None
        self.prev = None
    
class DoublyLinkedList:
    def __init__(self):
        self.head = None
        self.tail = None
        self.size = 0

    def from_array(self, mylist=None):
        self.head = None
        self.tail = None
        self.size = 0

        if mylist is None:
            return

        # append each from given list
        for element in mylist:
            self.append(element)
        
    def __repr__(self):
        s = "[ "
        current = self.head
        while current is not None:
            s += str(current.value) + " "
            current = current.next

        return f"{s}] Size: {self.count()}"
    
    def reverse(self):
        current = self.head
        while current is not None:
            next_node = current.next
            current.next, current.prev = current.prev, current.next
            current = next_node
        self.head, self.tail = self.tail, self.head
        
    def search(self, value):
        i = 0
        current = self.head
        while current is not None:
            if current.value == value:
                return i
            i += 1
            current = current.next
        raise Exception("Value not found")
    
    def insert(self, index, value):
        ''' need to check for index out of bounds '''
        i = 0
        
        # insert front
        if index == 0:
            self.append(value)
            return
            
        current = self.head
        while index < i or current is not None:
            i += 1
            if i == index:
                break
            current = current.next
        
        if index > i:
            raise Exception("Index Out of Bounds")
        new_node = Node(value)
        tmp = current.next
        current.next = new_node
        new_node.next = tmp

        
    def append(self, value):
        ''' append value to the end of the list '''
        
        if self.head is None:
            self.head = Node(value)
            if self.size == 0:
                self.tail = self.head
            self.size += 1
            return
        
        # go to the end of the list
        current = self.head
        while current.next is not None:
            current = current.next
        
        new_node = Node(value)
        current.next = new_node
        new_node.prev = current
        
        self.tail = new_node
        self.size += 1
        

    def delete(self, index):
        if self.head is None:
            raise Exception("LinkedList is Empty")

        i = 0
        if index == 0:
            self.head = self.head.next
            self.head.prev = None
            self.size -= 1
            return
        
        current = self.head
        while current is not None:
            if index == i:
                current.prev.next = current.next
                if current.next is not None:
                    current.next.prev = current.prev
                else:
                    self.tail = current.prev

                self.size -= 1
                return
            current = current.next
            i += 1
        raise Exception("Index not found")

    def count(self):
        return self.size
    
    def union(self, dll):
        ht = {}
        current = self.head
        while current:
            ht[current.value] = True
            current = current.next
        
        current = dll.head
        while current:
            if current.value not in ht:
                self.append(current.value)
            current = current.next
    


# In[ ]:


dll = DoublyLinkedList()
dll.from_array([10, 20, 30, 40, 50])
print(dll)
print(dll.head.value)
print(dll.tail.value)

dll.reverse()
print(dll)

dll.append(5)
print(dll)
print(dll.head.value)
print(dll.tail.value)


# In[ ]:


def print_iter(dll):
    current = dll.head
    while current:
        print(current.value, end=" ")
        current = current.next

print_iter(dll)
        


# In[ ]:


def print_iter_reverse(dll):
    current = dll.tail
    while current:
        print(current.value, end=" ")
        current = current.prev

print_iter_reverse(dll)


# 2. Write a function that takes two linked list and outputs a union of these two linked lists. Make it as efficient as possible. You can assume that each list consists of unique numbers and are not necessarily sorted. Also, the order of the output is not significant.
# 

# In[ ]:


#  [2, 10, 5, 3, 4] and [4, 7, 8, 3, 11] has a union of [2, 10, 3, 4, 5, 7, 8, 11]


# In[ ]:


dll1 = DoublyLinkedList()
dll1.from_array([2, 10, 5, 3, 4])
dll2 = DoublyLinkedList()
dll2.from_array([4, 7, 8, 3, 11] )


# In[ ]:


dll1.union(dll2)
dll1


# In[ ]:


dll1 = DoublyLinkedList()
dll1.from_array([2, 10, 5, 3, 4])
dll2 = DoublyLinkedList()
dll2.from_array([4, 7, 8, 3, 11] )
dll2.union(dll1)
print(dll1)
print(dll2)


# 3. Write the following binary search tree functions to:
# * Return the minimum value
# * Return the maximum value
# * Return the sum of all values
# 

# In[ ]:


class Node:
    def __init__(self, value):
        self.value = value
        self.left = None
        self.right = None
    
    def print(self, level=0):
        if self.right:
            self.right.print(level + 1)
        print("   " * level + str(self.value))
        if self.left:
            self.left.print(level + 1)
        
class Tree:
    def __init__(self, node=None):
        self.root = node
        
    def search(self, value):
        current = self.root
        
        while current is not None:
            if value == current.value:
                return True
            elif value < current.value:
                current = current.left
            elif value > current.value:
                current = current.right
            else:
                return False
        
        return False
    
    def insert(self, value):
        current = self.root
        
        while current is not None:
            if value < current.value:
                if current.left is None:
                    current.left = Node(value)
                    return
                else:
                    current = current.left
            elif value > current.value:
                if current.right is None:
                    current.right = Node(value)
                    return
                else:
                    current = current.right
            else:
                return False
        
        return False
    
    def delete_node(self, value, node=None):
        if node is None:
            node = self.root
        
        if value < node.value:
            node.left = self.delete_node(value, node.left)
        elif value > node.value:
            node.right = self.delete_node(value, node.right)
        else:
            if node.left is None:
                branch = node.right
                node = None
                return branch
            elif node.right is None:
                branch = node.left
                node = None
                return branch
            
            branch = self.min_node(node.right)
            node.value = branch.value
            node.right = self.delete_node(branch.value, node.right)
            
        return node

    def min_node(self, node=None):
        if node is None:
            node = self.root
        
        if node.left is None:
            return node
        else:
            return self.min_node(node.left)
    
    def min_value(self, node=None):
        mn_node = min_node(node)
        return mn_node.value
    
    def max_node(self, node=None):
        if node is None:
            node = self.root
        
        if node.right is None:
            return node
        else:
            return self.max_node(node.right)
    
    def max_value(self, node=None):
        mx_node = max_node(node)
        return mx_node.value
    
    def sum_tree(self):
        return self.sum_tree_rec(self.root)
        
    def sum_tree_rec(self, node):
        if node is None:
            return 0
        
        return node.value + self.sum_tree_rec(node.left) + self.sum_tree_rec(node.right)

    def sum_tree2(self, node=None):
        ''' verbose version of sum_tree '''
        if node is None:
            node = self.root
        
        if node.left is None:
            left_node = 0
        else:
            left_node = self.sum_tree2(node.left)

        if node.right is None:
            right_node = 0
        else:
            right_node = self.sum_tree2(node.right)

        
        return node.value + left_node + right_node

    def print(self):
        self.root.print()


# In[ ]:


n = Node(42)
n.left = Node(25)
n.left.left = Node(16)
n.left.right = Node(36)
n.left.right.left = Node(30)

n.right = Node(49)
n.right.left = Node(45)
n.right.left.left = Node(43)
n.right.right = Node(64)
n.right.right.right = Node(81)

t = Tree(n)
t.print()


# In[ ]:


print(t.min_node().value)
print(t.max_node().value)
print(t.sum_tree())
print(t.sum_tree2())


# #### 4. Write a function that accepts a binary tree and verifies whether it fulfills binary search tree conditions.
# 

# INACCURATE solution   

# In[ ]:


def verify_bst_1(node):
    if node.left == None and node.right == None:
        return True
    
    if node.left == None and node.right != None and node.value < node.right.value:
        return verify_bst_1(node.right)
    
    if node.right == None and node.left != None and node.left.value < node.value:
        return verify_bst_1(node.left)

    if node.left.value < node.value and node.value < node.right.value:
        return verify_bst_1(node.left) and verify_bst_1(node.right)
    else:
        return False


# should be a BST

# In[ ]:


node = Node(10)
node.left = Node(5)
node.left.left = Node(3)
node.left.right = Node(7)

node.right = Node(15)
node.right.left = Node(12)
node.right.right = Node(17)

t1 = Tree(node)
t1.print()
verify_bst_1(t1.root)


# should NOT be a BST

# In[ ]:


node = Node(10)
node.left = Node(15)
node.left.left = Node(3)
node.left.right = Node(7)

node.right = Node(14)
node.right.left = Node(12)
node.right.right = Node(17)

t2 = Tree(node)
t2.print()
verify_bst_1(t2.root)


# should NOT be a BST - the 6 should not be to the right of 10 -- fails the BST condition

# In[ ]:


node = Node(10)
node.left = Node(5)
node.left.left = Node(3)
node.left.right = Node(7)

node.right = Node(15)
node.right.left = Node(6)
node.right.right = Node(17)

t3 = Tree(node)
t3.print()
verify_bst_1(t3.root)


# An OK solution

# In[ ]:


def min_bst_value(node):
    while node.left != None:
        node = node.left
    return node.value

def max_bst_value(node):
    while node.right != None:
        node = node.right
    return node.value

def verify_bst_2(node):
    if node == None:
        return True
    
    if node.right != None and node.value >= min_bst_value(node.right):
        return False
    
    if node.left != None and max_bst_value(node.left) >= node.value:
        return False

    return verify_bst_2(node.left) and verify_bst_2(node.right)


# should be a BST

# In[ ]:


node = Node(10)
node.left = Node(5)
node.left.left = Node(3)
node.left.right = Node(7)

node.right = Node(15)
node.right.left = Node(12)
node.right.right = Node(17)

t1 = Tree(node)
t1.print()
verify_bst_2(t1.root)


# should NOT be a BST

# In[ ]:


node = Node(10)
node.left = Node(15)
node.left.left = Node(3)
node.left.right = Node(7)

node.right = Node(14)
node.right.left = Node(12)
node.right.right = Node(17)

t2 = Tree(node)
t2.print()
verify_bst_2(t2.root)


# should NOT be a BST

# In[ ]:


node = Node(10)
node.left = Node(5)
node.left.left = Node(3)
node.left.right = Node(7)

node.right = Node(15)
node.right.left = Node(6)
node.right.right = Node(17)

t3 = Tree(node)
t3.print()
verify_bst_2(t3.root)


# best, most efficient solution

# In[ ]:


import math
 
# Return true if the given tree is a BST and its values
# >= min and <= max
def verify_bst_3(node, mini=-math.inf, maxi=math.inf):     
    # An empty tree is BST
    if node is None:
        return True
 
    # False if this node violates min/max constraint
    if node.value < mini or node.value > maxi:
        return False
 
    # Otherwise check the subtrees recursively
    # tightening the min or max constraint
    return verify_bst_3(node.left, mini, node.value - 1) and verify_bst_3(node.right, node.value + 1, maxi)
 
root = Node(4)
root.left = Node(2)
root.right = Node(5)
root.left.left = Node(1)
root.left.right = Node(3)
 
verify_bst_3(root)


# should be a BST

# In[ ]:


node = Node(10)
node.left = Node(5)
node.left.left = Node(3)
node.left.right = Node(7)

node.right = Node(15)
node.right.left = Node(12)
node.right.right = Node(17)

t1 = Tree(node)
t1.print()
verify_bst_3(t1.root)


# should NOT be a BST

# In[ ]:


node = Node(10)
node.left = Node(15)
node.left.left = Node(3)
node.left.right = Node(7)

node.right = Node(14)
node.right.left = Node(12)
node.right.right = Node(17)

t2 = Tree(node)
t2.print()
verify_bst_3(t2.root)


# should NOT be a BST

# In[ ]:


node = Node(10)
node.left = Node(5)
node.left.left = Node(3)
node.left.right = Node(7)

node.right = Node(15)
node.right.left = Node(6)
node.right.right = Node(17)

t3 = Tree(node)
t3.print()
verify_bst_3(t3.root)

