#!/usr/bin/env python
# coding: utf-8

# 1. Describe the worst case data and the best case data for each of the following sorting algorithms:
# 
# ### Bubble Sort
# * worst case: array is sorted in reverse: maximum number of swaps (n) and requires n iterations - O(n^2)
# * best case: array is already sorted -- no swaps required - O(n)
# 
# 
# ### Selection Sort
# * worst case: array is sorted in reverse or contains a large number of duplicate elements: maximum number of swaps (n) and requires n iterations - O(n^2)
# * best case: already sorted so no swaps are required. Still requires O(n^2) because of the nested loop required.
# 
# ### Insertion Sort
# * worst case: array is sorted in reverse. This requires plenty of shifting. Usually occurs when low values are at the end and have to be inserted at the front of an array. O(n^2)
# * best case: already sorted - no shifting and insertion is required. O(n)
# 
# 
# ### Merge Sort
# log n divides are going to occur, regardless of the state of the data
# merging will take n times, no matter what the order of the data is
# * worst case: - O(n log n)
# * best case: - O(n log n)
# 
# 
# ### Quicksort
# * worst case: the array is already sorted or sorted in reverse order and then choosing the wrong pivot (something that is not a median). This results in unbalanced halves: one with 0 elements and another with n-1 elements. - O(n^2)
# 
# * best case: correctly chosen pivot (median) - O(n log n)
# 
# 
# 

# 2. Implement the insertion sort function.

# In[ ]:


def insert(array, i, j):
    ''' insert element at j to i. 
        shift elements between i and j one elment to the right '''
    temp = array[i]
    for k in range(i - 1, j - 1, -1):
        array[k + 1] = array[k]
    array[j] = temp

def insertion_sort(array, verbose=True):
    comparisons, inserts = 0, 0
    for i in range(1, len(array)):
        for j in range(i):
            comparisons += 1
            if array[i] < array[j]:
                inserts += 1
                insert(array, i, j)
                break
        if verbose:
            print(array)
    print(f"Total inserts: {inserts:,} comparisons: {comparisons:,}")

    return array


insertion_sort([3, 2, 1, 0])


# In[ ]:


a = [1, 2, 3, 4, 0, 10, -5, 15, 55, 23, 88, 44, 73, -2]

insertion_sort(a)


# In[1]:


import dsa.sorttools as st
array = st.rand_int_array(10_000, 1000)


# In[ ]:


get_ipython().run_cell_magic('time', '', 'a = insertion_sort(array, verbose=False)\n')


# 3. Write a function that accepts an array of size n containing random numbers ranging from 0 to n-1.
#    * This array may contain duplicates
#    * The numbers are not arranged in any particular order
# 
# This function should return a new array that consists of any missing numbers within the range from 0 to n-1.
# 
# This function must have a time complexity of O(n) to get full credit.
# 
# For example:
# find_missing([0, 3, 6, 7, 3, 3, 0, 4]) # returns [ 1, 2, 5 ]
#  

# In[ ]:


def find_missing(array):
    ht = dict()
    missing = list()
    
    for i in range(len(array)):
        ht[array[i]] = True

    for i in range(len(array)):
        if i not in ht:
            missing.append(i)
            
    return missing
    
find_missing([0, 3, 6, 7, 4])


# 4. Write a function that returns the first non-repeating consecutive character in a string with O(n) efficiency. It should return none or null if there are no non-repeating characters.
# 
# For example:  
# * string "aaaaabbbbbbc" should return "c" 
# * string "aabab" should return "b"
# * string "aababb" should return None ("b" is repeating)
#    

# In[22]:


def first_nonrepeating_char(s):
    cf_table = {}
    consecutive = {}
    
    # fill character frequency table
    prev = None
    for c in s:
        # if it's consecutive, then it is repeating and we place it in another hash table
        if prev == c: 
            consecutive[c] = True
        else:
            cf_table[c] = 0
        if c in cf_table:
            cf_table[c] += 1
        else:
            cf_table[c] = 1
        prev = c

    # find the first non-repeating character
    for c in s:
        if cf_table[c] == 1 and c not in consecutive:
            return c

    return None

print(None, first_nonrepeating_char(""))
print(None, first_nonrepeating_char("aa"))
print(None, first_nonrepeating_char("aabb"))
print("c", first_nonrepeating_char("aaaaabbbbbbc"))
print("c", first_nonrepeating_char("aaaaaac"))
print("a", first_nonrepeating_char("abc"))
print("b", first_nonrepeating_char("aaba"))
print("b", first_nonrepeating_char("aabab"))
print("c", first_nonrepeating_char("aabbabc"))
print(None, first_nonrepeating_char("aacbbabcc")) # c repeats, so it is rejected


# 5. Write a function that given an array of integers and a target value, returns the length of the longest subarray with a sum equal to the target value.
# Note: while the sliding window technique is acceptable as a solution, try solving this using a hash table.
#  
# For example: Given an array: [3, 1, -1, 2, -1, 5, -2, 3] and a target value of 3, the longest substring length is 5 ([-1, 2, -1, 5, -2]
# 

# In[17]:


def longest_subarray_sum(array, target):
    prefix_sum = {}
    max_length = 0
    current_sum = 0

    for i, num in enumerate(array):
        current_sum += num

        # if the current_sum equals the target sum target, update the max_length
        if current_sum == target:
            max_length = i + 1

        # if the complement is in prefix_sum, it means there is a subarray with sum k
        # update max_length accordingly
        complement = current_sum - target
        if current_sum - target in prefix_sum:
            max_length = max(max_length, i - prefix_sum[complement])

        # store the current prefix sum and its index in the hashtable
        if current_sum not in prefix_sum:
            prefix_sum[current_sum] = i

    return max_length

print(longest_subarray_sum([3, 1, -1, 2, -1, 5, -2, 3], 3))
print(longest_subarray_sum([1, 1, 1, 2, 1, 1, 3, -1, 1, 2, 1], 5))
print(longest_subarray_sum([1, 1, 1, 2, 1, 1, 3, -1, 1, 2, 1], 4))
print(longest_subarray_sum([1, 1, 1, 2, 1, 1, -3, -1, 1, 2, 1], 4))


# N.B.: The above is similar to the Two Sums problem. Below is a detailed explanation of it (retrieved from ChatGPT).

# 
# The "Two Sum" problem is a common coding interview question in computer science and programming. It is often used to test a candidate's understanding of data structures and algorithms. The problem statement goes like this:
# 
# **Problem Statement:**
# 
# Given an array of integers `nums` and an integer `target`, return the indices of the two numbers such that they add up to the `target`. You may assume that each input would have exactly one solution, and you may not use the same element twice. You can return the answer in any order.
# 
# **Example:**
# 
# Input: `nums = [2, 7, 11, 15], target = 9`
# 
# Output: `[0, 1]`
# 
# Explanation: The sum of `nums[0]` and `nums[1]` equals 9, so the output is `[0, 1]`.
# 
# **Solution Approach:**
# 
# The brute-force solution involves checking every pair of numbers in the array to see if they add up to the target. However, this approach has a time complexity of O(n^2) since you would need two nested loops to compare all pairs.
# 
# A more efficient approach is to use a hash map (dictionary) to store the values encountered so far and their corresponding indices. Here's a step-by-step algorithm:
# 
# 1. Initialize an empty dictionary or hash map to store values and their indices.
# 
# 2. Iterate through the given array `nums` using a `for` loop.
# 
# 3. For each element `num` at index `i` in the array, calculate the `complement` as `target - num`.
# 
# 4. Check if the `complement` exists in the dictionary. If it does, you have found a pair of elements that add up to the `target`. Return the indices of `num` and its complement.
# 
# 5. If the `complement` is not in the dictionary, add `num` to the dictionary with its index as the value.
# 
# 6. If no solution is found after iterating through the entire array, return an empty list or handle it as necessary based on the problem constraints.
# 
# Here's a Python code snippet that implements this approach:
# 
# ```python
# def two_sum(nums, target):
#     num_indices = {}  # Dictionary to store values and their indices
#     for i, num in enumerate(nums):
#         complement = target - num
#         if complement in num_indices:
#             return [num_indices[complement], i]
#         num_indices[num] = i
#     return []  # If no solution is found
# ```
# 
# This algorithm has a time complexity of O(n) because it only requires a single pass through the array.

# In[ ]:




