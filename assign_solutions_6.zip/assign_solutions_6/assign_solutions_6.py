#!/usr/bin/env python
# coding: utf-8

# 1. Write a depth first search function  that accepts a starting vertex and and an ending vertex. If the ending vertex is found, It should also return the path of the search.

# In[ ]:


from dsa.graph import Vertex

def dfs(start, end, visited=None, path=None):
    if visited is None:
        visited = {}

    if path is None:
        path = []

    visited[start] = True
    path = path + [start]

    if start == end:
        return path

    for adjacent in start.adjacents:
        if adjacent not in visited:
            new_path = dfs(adjacent, end, visited, path)
            if new_path:
                return new_path
    return None


a = Vertex("A")
b = Vertex("B")
c = Vertex("C")
d = Vertex("D")
e = Vertex("E")
f = Vertex("F")
a.add_adjacent_vertex(b)
a.add_adjacent_vertex(d)

b.add_adjacent_vertex(a)
b.add_adjacent_vertex(c)
b.add_adjacent_vertex(f)

c.add_adjacent_vertex(b)
c.add_adjacent_vertex(d)
c.add_adjacent_vertex(f)

d.add_adjacent_vertex(a)
d.add_adjacent_vertex(c)
d.add_adjacent_vertex(e)

e.add_adjacent_vertex(d)
e.add_adjacent_vertex(f)

f.add_adjacent_vertex(b)
f.add_adjacent_vertex(c)
f.add_adjacent_vertex(e)

print(dfs(a, b))
print(dfs(a, f))
print(dfs(d, b))
print(dfs(f, a))


# 2. Implement a breadth first search function that accepts a starting vertex and an ending vertex of a graph. This time, assume that the graph is implemented using an adjacency matrix.

# In[ ]:


from dsa.graph import AdjacencyMatrixGraph

def bfs_adjacency_matrix(graph, start, end):
    visited = set()
    start_label = graph.label_index[start]
    end_label = graph.label_index[end]
    print(start_label, end_label)
    queue = [start_label]

    while queue:
        current = queue[0]
        del queue[0]

        if current == end_label:
            return True

        # Otherwise, mark the vertex as visited and enqueue its neighbors
        visited.add(current)
        for adjacent, is_edge in enumerate(graph.array[current]):
            if is_edge and adjacent not in visited:
                queue.append(adjacent)

    # If the end vertex not found, return False
    return False

# directed graph
dgraph = AdjacencyMatrixGraph(["A", "B", "C", "D", "E", "F"])
dgraph.add_adjacent_directed_vertex("A", "B")
dgraph.add_adjacent_directed_vertex("A", "D")

dgraph.add_adjacent_directed_vertex("B", "C")
dgraph.add_adjacent_directed_vertex("B", "F")

dgraph.add_adjacent_directed_vertex("C", "D")
dgraph.add_adjacent_directed_vertex("C", "F")

dgraph.add_adjacent_directed_vertex("D", "E") 
dgraph.add_adjacent_directed_vertex("E", "F") 
dgraph.print_graph()

print(bfs_adjacency_matrix(dgraph, start="A", end="D"))
print(bfs_adjacency_matrix(dgraph, start="A", end="F"))
print(bfs_adjacency_matrix(dgraph, start="C", end="D"))
print(bfs_adjacency_matrix(dgraph, start="C", end="E"))
print(bfs_adjacency_matrix(dgraph, start="F", end="A"))



# 3. Why does Djikstra's Algorithm NOT work for graphs with negative weights?

# Dijkstra's algorithm works by exploring the vertices in a graph in a greedy manner, choosing the next vertex with the smallest distance from the starting vertex. It assumes that all the edges in the graph have non-negative weights. If there are negative weights, then the algorithm may not produce the correct shortest path, as it may get stuck in a cycle where the negative weights cause the distance to decrease indefinitely.

# 4. Write a function that accepts a directed acyclic graph (DAG) and a path. It should return whether the path is valid or not.

# In[ ]:


from dsa.graph import Vertex

def is_valid_path(path):
    if len(path) == 0:
        return False

    previous = path[0]

    for vertex in path[1:]:
        if vertex not in previous.adjacents:
            return False
        previous = vertex

    return True

a = Vertex("A")
b = Vertex("B")
c = Vertex("C")
d = Vertex("D")
e = Vertex("E")
f = Vertex("F")

a.add_directed_adjacent_vertex(b)
a.add_directed_adjacent_vertex(d)

b.add_directed_adjacent_vertex(c)
b.add_directed_adjacent_vertex(f)

c.add_directed_adjacent_vertex(d)
c.add_directed_adjacent_vertex(f)

d.add_directed_adjacent_vertex(e)

e.add_directed_adjacent_vertex(f)

path1 = [a, b, c, d, e, f]
print(is_valid_path(path1))

path2 = [a, c]
print(is_valid_path(path2))

path3 = [b, c, d]
print(is_valid_path(path3))

path4 = [b, c, d, f]
print(is_valid_path(path4))


# In[ ]:




