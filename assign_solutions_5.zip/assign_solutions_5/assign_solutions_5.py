#!/usr/bin/env python
# coding: utf-8

# (25 points) Use either Java, Python, C or C++
# 
# 1. Write a function to get the last item in a complete tree. This is easy to do if the complete tree were implemented using arrays. How would we do this if the tree was implemented using nodes?

# In[ ]:


from dsa.tree import Node, Tree
from dsa.pretty_print import tree_print


# In[ ]:


a = Node(18)
a.left = Node(15)
a.right = Node(30)
a.left.left = Node(40)
a.left.right = Node(50)
a.left.right.left = Node(10)

a.left.left.left = Node(6)
a.left.left.right = Node(3)

a.right.left = Node(100)
a.right.right = Node(40)

tree = Tree(a)
tree_print(tree)


# In[ ]:


def bf_last(tree):
    current = tree.root
    queue = []
    
    queue.append(current)
    
    while len(queue) > 0:
        current = queue[0]
        del queue[0]
        
        if current.left:
            queue.append(current.left)
        if current.right:
            queue.append(current.right)
        
    return current.value

bf_last(tree)


# ### depth first solution 

# * calculate the height of the tree
# * keep on going right if the height matches the subtree height
# * if at the end, return the value
# 
# Complexity of O(log n^2), which is better than breadth first, which visits all of the nodes.
# O(log n^2) results from getting the height of the tree (log N) and time to traverse each step is O(log N). log n * O(log N) == O(log N^2)

# In[ ]:


def rightmost_node(root):
    if not root:
        return None

    height = get_height(root)
    node = root
    while height > 1:
        if get_height(node.right) == height - 1:
            node = node.right
        else:
            node = node.left
        height -= 1
    return node.value

def get_height(node, height=0):
    if not node:
        return height
    else:
        return get_height(node.left, height + 1)

rightmost_node(tree.root)


# 2. (25 points) Write a heap sort function. We've looked at max heap, which will sort our array in reversed order. Therefore, you will need to implement heap sort as a min heap to sort an array in ascending order. 
# #### Try implementing it without looking at the source code for max heap.

# In[ ]:


class Heap:
    def __init__(self, ascending=True):
        self.array = []
        if ascending:
            self.comparator = lambda x: -x
        else:
            self.comparator = lambda x: x
    
    def root(self):
        if self.size() == 0:
            return None

        return self.array[0]
    
    def last(self):
        if self.size() == 0:
            return None

        return self.array[-1] 
    
    def left_index(self, index):
        return (index * 2) + 1

    def right_index(self, index):
        return (index * 2) + 2

    def parent_index(self, index):
        return (index - 1) // 2
    
    def has_left(self, index):
        return self.left_index(index) < self.size()
    
    def has_right(self, index):
        return self.right_index(index) < self.size()

    def has_parent(self, index):
        return self.parent_index(index) >= 0
    
    def insert(self, value):
        self.array.append(value)
        
        start_index = self.size() - 1
        self.heapify_up(start_index)
    
    def heapify_up(self, index):
        parent_index = self.parent_index(index)
        while self.has_parent(index) and self.comparator(self.array[index]) > self.comparator(self.array[parent_index]):
            self.array[index], self.array[parent_index] = self.array[parent_index], self.array[index]
            index = parent_index
            parent_index = self.parent_index(index)

    def pop(self):
        root_value = self.root()
        
        # start at root node
        start_index = 0
        if self.size() == 1:
            self.array.pop()
        else:
            self.array[start_index] = self.array.pop()
        
        self.heapify_down(start_index)
        return root_value
        
    def heapify_down(self, index):
        while self.has_left(index):
            higher_index = self.left_index(index)

            right_index = self.right_index(index)
            if self.has_right(index) and self.comparator(self.array[right_index]) > self.comparator(self.array[higher_index]):
                higher_index = right_index
            
            if self.comparator(self.array[index]) > self.comparator(self.array[higher_index]):
                break
            else:
                self.array[index], self.array[higher_index] = self.array[higher_index], self.array[index]
                
            index = higher_index
    
    def size(self):
        return len(self.array)
    
    def print(self):
        node_count = 1
        for i in range(self.size()):
            if i + 1 >= node_count:
                print()
                node_count *= 2
            print(self.array[i], end=" ")

def heap_sort(array, ascending=False):
    h = Heap(ascending=ascending)
    for e in array:
        h.insert(e)
        
    i = 0
    while h.size() > 0:
        array[i] = h.pop()
        i += 1
        
    return array
    
print(heap_sort([2, 4, 20, 15, 12, 17, 8, 99, 42, 36, 81, 74], ascending=True))
print(heap_sort([2, 4, 20, 15, 12, 17, 8, 99, 42, 36, 81, 74], ascending=False))
print(heap_sort([2, 3, 1], ascending=True))
print(heap_sort([2, 3], ascending=True))
print(heap_sort([3, 2], ascending=True))
print(heap_sort([4], ascending=True))
print(heap_sort([], ascending=True))


# 3. Write a function that given an array of words, returns the longest common prefix. Write it so that it performs efficiently.
# 

# In[ ]:


from dsa.trie import Trie

def longest_prefix(words):
    tr = Trie()
    for word in words:
        tr.insert(word)    

    prefix = ""
    current = tr.root

    # if the number of the children is one, then the current character
    # node is shared, otherwise it has unique paths
    # Example:
    # [a]
    #  |
    # [p]
    #  |
    # [p]
    #  | \  \
    # [a] [e] [l]  
     
    while len(current.children) == 1:
        # get the key
        key = list(current.children.keys())[0]

        # go to the next character
        current = current.children[key]

        # build the prefix
        prefix = prefix + current.value
    
    return prefix
        
words = ["apple", "appetite", "apparatus", "appliance"]
longest_prefix(words)


# 4. Write a function that accepts an array of words and then returns the shortest unique prefix of each word.

# for example

# In[ ]:


words = ['apple', 'banana', 'cherry', 'cranberry', 'grape', 'grapefruit'] 

# 'apple' returns 'a'
# 'banana' returns 'b'
# 'cherry' returns 'ch'
# 'cranberry' returns 'cr'
# 'grape' returns 'grape'
# 'grapefruit' returns 'grapef'
# returns:
['a', 'b', 'ch', 'cr', 'grape', 'grapef']


# In[ ]:


class TrieNode:
    def __init__(self):
        self.children = {}
        # the number of shared words (incomplete: not implemented in delete)
        self.share_count = 0

    def __repr__(self):
        return f"{list(self.children.keys())} Count: {self.share_count}"
        
class Trie:
    def __init__(self):
        self.root = TrieNode()
        self.end_char = "*"
            
    def insert(self, word):
        current = self.root
        for c in word:
            if c not in current.children:
                current.children[c] = TrieNode()

            current = current.children[c]
            current.share_count += 1

        current.children[self.end_char] = None
        current.is_end = True
    
    def search(self, s):
        if len(s) == 0:
            return None

        current = self.root
        for c in s:
            if c not in current.children:
                return None
            current = current.children[c]
        return current
    
    def delete(self, word, i=0, current=None):
        if i == len(word):
            return True

        if current is None:
            current = self.root
            word = word + self.end_char

        char = word[i]
        if char not in current.children:
            return False
        
        next_node = current.children[char]
        should_delete_ref = self.delete(word, i + 1, next_node)

        if should_delete_ref:
            del current.children[char]
            return len(current.children) == 0
        return False
    
    def print_keys(self, current):
        if current is None:
            return

        for c in current.children:
            self.print_keys(current.children[c])
            
    def print_words(self, node=None, word="", words=None):
        if words is None:
            words = []
        current = node
        if node is None:
            current = self.root
        
        for key, node in sorted(current.children.items()):
            if key == self.end_char:
                words.append(word)
            else:
                self.print_words(node, word + key, words)
        return words
    
    def autocomplete(self, prefix):
        current = self.search(prefix)
        if current is None:
            return None
        return self.print_words(current, prefix)
    
    def suggest(self, s):
        if s is None or len(s) == 0:
            return None
        suggestions = self.autocomplete(s)
        if suggestions is None or len(suggestions) == 0:
            return self.suggest(s[:-1])
        else:
            return suggestions
    
def shortest_prefix(node, word, debug=False):
    prefix = ''

    # iterate through each character in word
    for c in word:
        # if the character is the member of the current node, append it
        # to the prefix
        if c in node.children:
            prefix += c
            # if the count of the next node == 1, the prefix is unique
            if debug:
                print(f'Word: {word}\tChar: {c} Prefix: {prefix} Count: {node.children[c].share_count}')
            if node.children[c].share_count == 1:
                return prefix
            # otherwise, go to the next node
            node = node.children[c]

    return prefix

def find_shortest_prefixes(words, debug=False):   
    trie = Trie()
    for word in words:
        trie.insert(word)

    prefixes = []
    
    for word in words:
        prefix = shortest_prefix(trie.root, word, debug)
        prefixes.append(prefix)
    
    return prefixes

words = ['apple', 'banana', 'cherry', 'cranberry', 'grape', 'grapefruit'] 
find_shortest_prefixes(words)


# In[ ]:


find_shortest_prefixes(words, debug=True)


# In[ ]:





# In[ ]:




